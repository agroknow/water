<?php
/*
 * Science Links
 */
?>
<h2 class="centered" data-theme-tpl="block--block--6">Science Links</h2>
<div class="clearfix">
    <a href="http://qmrawiki.msu.edu/" class="exticons quantitative clearfix">
        <span>Quantitative Microbial Risk Assessment</span>
    </a>
    <a href="http://www.thiswormyworld.org/" class="exticons global clearfix">
        <span>Global Atlas of Helminth Infections</span>
    </a>
</div>