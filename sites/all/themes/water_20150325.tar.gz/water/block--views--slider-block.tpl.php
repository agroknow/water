<!--slider: http://kenwheeler.github.io/slick/-->
<section id="slider" data-theme-tpl="block--views--slider-block">
    <div id="slides">
        <?php print $content ?>
        <!--div class="slide" style="background:#f26c4f url(<?php print $base_path . path_to_theme()?>/img/ss1_mini.jpg) top center no-repeat;"></div>
                <div class="slide" style="background:#f26c4f url(<?php print $base_path . path_to_theme()?>/img/ss2_mini.jpg) top center no-repeat;"></div>
                <div class="slide" style="background:#f26c4f url(<?php print $base_path . path_to_theme()?>/img/ss3_mini.jpg) top center no-repeat;"></div-->
    </div>
<!-- about_us -->
    <aside>
        <div class="center clearfix">
            <h2><?php print t('About GWPP')?></h2>
            <p><?php print t('To reduce the lack of sustainable access to safe drinking water and basic sanitation GWPP will update knowledge on water pathogens using advanced information technologies by publishing and disseminating a state-of-the-art reference work on water-related disease risks and intervention measures (replacing <strong>Sanitation and Disease Health Aspects of Excreta and Wastewater Management</strong> by Feachem, Bradley, Garelick and Mara. 1983) and create an online open-access data base and knowledge platform. GWPP will provide an updated review of the efficacy of sanitation technologies and serve as a compendium of waterborne pathogen information and quantitative data to support risk assessment to protect water safety. Work will also be conducted with the World Health Organization to support its Sanitation Guidelines.')?></p>
        </div>
    </aside>
</section>