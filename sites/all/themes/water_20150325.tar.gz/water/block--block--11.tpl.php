<?php
/*
 * Partners
 */
?>
<section class="block firstblock" data-theme-tpl="block--block--11">
    <p>
        UNESCO is serving as the Project Leader for the revision of Health Aspects of Excreta and Sanitation in Collaboration with MSU.
    </p>
</section>
<section class="block secondblock">
    <p>
        MSU in collaboration with the GWP network and Agroknow is building the GWP Knowledge Hub.
    </p>
</section>
<section class="block">
    <p>
        Funding for the GWPP is supported by the Michigan State University Midland Research Institute for Value Chain Creation.
    </p>
</section>
<section class="block">
    <p>
        The GWP network is grateful for the gift from Procter and Gamble.
    </p>
</section>