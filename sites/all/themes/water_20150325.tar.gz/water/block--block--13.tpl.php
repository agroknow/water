<?php
/*
 * Featured Sections
 */
?>
<h2 class="centered" data-theme-tpl="block--block--13">Featured Sections</h2>
<div class="clearfix">
    <a href="#" class="topicons">
        <span class="icon library ir">Library</span>
        <h3>Library</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent luctus, erat at.</p>
    </a>
    <a href="#" class="topicons">
        <span class="icon publications ir">Publications</span>
        <h3>Publications</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent luctus, erat at.</p>
    </a>
    <a href="#" class="topicons">
        <span class="icon presentations ir">Presentations</span>
        <h3>Presentations</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent luctus, erat at.</p>
    </a>
    <a href="#" class="topicons">
        <span class="icon seminars ir">Seminars</span>
        <h3>Seminars</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent luctus, erat at.</p>
    </a>
</div>