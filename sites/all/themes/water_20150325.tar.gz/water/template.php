<?php

/*
 * hook_theme
 */
function water_theme($existing, $type, $theme, $path){
    //varDumpDebug('water_theme......'.drupal_get_path('theme', 'water'));
    //varDumpDebug('water_theme......'.$path);
    $langDDFormTpl = array(
            'render element' => 'form',
            'path' => $path ,
            'template' => 'lang-dropdown-form');
    return array(
        'lang_dropdown_form' => $langDDFormTpl
    );
}

/**
 * Preprocessor for lang_dropdown_form_language theme.
 */
function water_preprocess_lang_dropdown_form(&$variables){
     //varDumpDebug('water_preprocess_lang_dropdown_form_language.......'.drupal_get_path('theme', 'water'));
    //var_export($variables);
}

/*
 * theme search block form
 * https://www.drupal.org/node/154137
 */
function water_form_alter(&$form, &$form_state, $form_id) {
  if ($form_id == 'search_block_form') {
      $form['search_block_form']['#attributes']['title'] = t('Type a keyword to search in GWP page');
      $form['search_block_form']['#attributes']['placeholder'] = t('Type a keyword to search in GWP page');
      $form['actions']['submit']['#value'] = "";
      $form['search_block_form']['#field_suffix'] = drupal_render($form['actions']['submit']);
  }
}

/*
 * hook_form, hook_form_element etc
 */

/**
 * Preprocess variables for page.tpl.php
 * default variales for page.tpl.php:
 * $logo, $front_page, $site_name, $site_slogan, $messages
 * $title_prefix, $title_suffix, $tabs, $action_links
 * $feed_icons, $breadcrumb
 */
function water_preprocess_page(&$vars) {
    //var_dump($vars);
    //var_export($vars);
    //var_dump(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS));
    
   /* $vars['page_bottom_script_tags'] = ''.
        '<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>'.
        '<script>window.jQuery || document.write(\'<script src="'.base_path() . path_to_theme().'/js/vendor/jquery-1.11.1.min.js"><\/script>\')</script>'.
        '<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>'.
        '<script src="'.base_path() . path_to_theme().'/js/vendor/slick.min.js"></script>'.
        '<script>var oWaterJQuery = $.noConflict(true);</script>'.
        '<script src="'.base_path() . path_to_theme().'/js/main.js"></script>';*/
    

//    $vars['contact_form'] = drupal_render(drupal_get_form('contact_site_form'));
}

/**
 * Preprocess variables for html.tpl.php
 */
function water_preprocess_html(&$variables) {
    $variables['page_bottom_script_tags'] = ''.
        '<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>'.
        '<script>window.jQuery || document.write(\'<script src="'.base_path() . path_to_theme().'/js/vendor/jquery-1.11.1.min.js"><\/script>\')</script>'.
        '<script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>'.
        '<script src="'.base_path() . path_to_theme().'/js/vendor/slick.min.js"></script>'.
        '<script>var oWaterJQuery = $.noConflict(true);</script>'.
        '<script src="'.base_path() . path_to_theme().'/js/main.js"></script>';
    
    
    /*
     * google fonts
     */
    drupal_add_css('http://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800&subset=latin,greek-ext', array('type' => 'external'));
    drupal_add_css('http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,700&subset=latin,greek-ext', array('type' => 'external'));
    /*
     * core js libraries
     */
    drupal_add_js(drupal_get_path('theme', 'water') . '/js/vendor/modernizr-2.6.2.min.js"');
    
}

/**
 * Page alter.
 */
function water_page_alter($page) {
}

/*
 * hook theme_menu_tree (defined in includes/menu.inc)
 */
function water_menu_tree__user_menu($variables){
    //return '<ul class="menu">' . $variables['tree'] . '</ul>';
    return $variables['tree'];
}

/*
 * hook theme_menu_link (defined in includes/menu.inc)
 * 
 * customize display of user menu
 * sample:
 * <a href="#" id="login" class="ir">login</a>
 * <a href="#" id="logout" class="ir">logout</a>
 */
function water_menu_link__user_menu($variables){
  $element = $variables['element'];
  $sub_menu = '';

  if ($element['#below']) {
    $sub_menu = drupal_render($element['#below']);
  }
//set class
    if(isset($element['#localized_options']['attributes']['class'])){
        $element['#localized_options']['attributes']['class'][] = "ir";
    }
    else{
        $element['#localized_options']['attributes']['class'] = array("ir");
    }
//set id
    if(strpos($element['#href'], "logout") !== FALSE ){
        $element['#localized_options']['attributes']['id'] = "logout";
    }
    else{
        $element['#localized_options']['attributes']['id'] = "login";
    }
//generate anchor html with l()    
    $output = l($element['#title'], $element['#href'], $element['#localized_options']);   
    
  return $output;
}

/*
 * hook theme_menu_tree (defined in includes/menu.inc)
 */
function water_menu_tree__main_menu($variables){
    return '<ul class="clearfix">' . $variables['tree'] . '</ul>';
}

/*
 * custom theme_menu_tree for submenu
 */
function water_menu_tree__main_menu_sub($variables){
    return '<ul>' . $variables['tree'] . '</ul>';
}
/*
 * hook theme_menu_link (defined in includes/menu.inc)
 */
function water_menu_link__main_menu($variables){
  $element = $variables['element'];
  $sub_menu = '';
  $elm_classes = array();
  $class_attribute = '';

  if ($element['#below']) {
    $element['#below']['#theme_wrappers'] = array('menu_tree__main_menu_sub');
    $sub_menu = drupal_render($element['#below']);
    $elm_classes[] = 'hassub';
//set class for trigger of submenu
    if(isset($element['#localized_options']['attributes']['class'])){
        $element['#localized_options']['attributes']['class'][] = "subtrigger";
    }#
    else{
        $element['#localized_options']['attributes']['class'] = array("subtrigger");
    }
  }
//generate anchor html with l()    
    $output = l($element['#title'], $element['#href'], $element['#localized_options']);
//add active class if menu item is selected    
    if (($element['#href'] == $_GET['q'] || ($element['#href'] == '<front>' && drupal_is_front_page())) && (empty($options['language']) || $options['language']->language == $language_url->language)) {
        $elm_classes[] = 'active';
    }
    
    foreach($elm_classes as $class){
        $class_attribute .= $class." ";
    }
    $class_attribute = trim($class_attribute);
    
    if($class_attribute == ""){
        $output = "<li>" . $output . $sub_menu ."</li>";
    }
    else{
        $output = "<li class='" . $class_attribute . "' >" . $output . $sub_menu ."</li>";    
    }    
//    $output = '<li' . drupal_attributes($element['#attributes']) . '>' . $output . $sub_menu . "</li>\n";

    return $output;
}

/*
 * hook theme_breadcrumb
 */
function water_breadcrumb($variables){
    $breadcrumb = $variables['breadcrumb'];

  if (!empty($breadcrumb)) {
      $crumbs = '<nav class="breadcrumbs clearfix">';

      foreach($breadcrumb as $value) {
           $crumbs .= $value;
      }
      $crumbs .= '</nav>';
    }
      return $crumbs;
}

function isFrontPage(){
    return (strtolower($_GET['q']) == $front_page);
}

function varDumpDebug($var){
    print '<br/>**************************<br/>';
    print '**************************<br/>';
    print '**************************<br/>';
    var_dump($var);    
    //dpm()
    //ddebug_backtrace($pop = 0)
}