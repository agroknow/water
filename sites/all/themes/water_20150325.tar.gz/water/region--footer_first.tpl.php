<?php
/*
 * REGION THEMING
 * https://www.drupal.org/node/1089656
 * 
 * DEFAULT region.tpl.php IMPLEMENTATION IN 
 * modules/system/region.tpl.php
 */
?>
<section class="footer-top">
    <div class="center clearfix">
<?php if ($content): ?>
  <?php print $content; ?>
<?php endif; ?>
    </div>
</section>