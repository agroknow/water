<section class="search clearfix" data-theme-tpl="block--search--form">
    <?php print $content ?>
    <a href="#">A-z Glossary</a>
    <a href="<?php print base_path(); ?>search/node">Advanced Search</a>
</section>
