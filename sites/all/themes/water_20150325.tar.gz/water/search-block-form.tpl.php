<?php

/*
DEFAULT search-block-form.tpl.php IMPLEMENTATION IN 
modules/search/search-block-form.tpl.php
*/
//var_export($variables);
//var_export($search);

//The complete search form ready for print.
print $search_form;
?>

