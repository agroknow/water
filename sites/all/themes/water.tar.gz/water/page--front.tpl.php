<header id="header">
    <div class="center clearfix">
<!-- *****
logo
****** -->
        <?php if ($logo):?>
        <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home" class="logo ir"><?php print $site_name;?></a>
        <?php endif; ?>
<!-- *****
header_top_right: user_menu, lang_switcher
****** -->
        <?php print render($page['header_top_right']); ?>
<!-- *****
navigation: main_menu
****** -->
        <?php print render($page['navigation']); ?>
<!-- *****
header: search_block
****** -->
        <?php print render($page['header']); ?>
    </div>
</header>

<!-- *****
banner: slider(about_us)
***** -->
<?php print render($page['banner']); ?>

<section id="blocks">            
    <div class="center">
<!-- *****
sidebar_first: featured_sections, science_links
****** -->
    <?php print render($page['sidebar_first']); ?>
<!-- *****
sidebar_second: view_latest_events, view_latest_new
****** -->
        <?php print render($page['sidebar_second']); ?>
        <!--section class="twocols clearfix">
            <section class="simpleview">
< !-- view_latest_news -- >
                <h2 class="withrightlink clearfix">Latest News<a href="#">All news</a></h2>
                <article class="clearfix">
                    <time datetime="2014-12-20 20:00"><span>20</span> January</time>
                    <img src="img/sample170x92.jpg" />
                    <h3>This is a latest new title</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus risus libero. </p>
                    <footer class="clearfix"><a href="#" class="author">by GKB</a><a href="#" class="more">more</a></footer>
                </article>                        
                <article class="clearfix">
                    <time datetime="2014-12-20 20:00"><span>20</span> January</time>
                    <img src="img/sample170x92.jpg" />
                    <h3>This is a latest new title</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus risus libero. </p>
                    <footer class="clearfix"><a href="#" class="author">by GKB</a><a href="#" class="more">more</a></footer>
                </article>                        
                <article class="clearfix">
                    <time datetime="2014-12-20 20:00"><span>20</span> January</time>
                    <img src="img/sample170x92.jpg" />
                    <h3>This is a latest new title</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus risus libero. </p>
                    <footer class="clearfix"><a href="#" class="author">by GKB</a><a href="#" class="more">more</a></footer>
                </article>                        
            </section>                    
        </section-->            
    </div>  <!-- .center -->          
</section><!-- #blocks -->

<!-- *****
bottom_content: twitter_slider
****** -->
<?php print render($page['bottom_content']); ?>

<footer id="footer">
<!-- *****
footer_first: bottom_menu, connect_with_us, contact_form
****** -->
    <?php print render($page['footer_first']); ?>
<!-- *****
footer_second: partners
****** -->
    <?php print render($page['footer_second']); ?>
<!-- *****
footer_third: copyright
****** -->
    <?php print render($page['footer_third']); ?>
</footer>