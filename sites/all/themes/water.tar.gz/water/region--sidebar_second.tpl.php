<?php
/*
 * REGION THEMING
 * https://www.drupal.org/node/1089656
 * 
 * DEFAULT region.tpl.php IMPLEMENTATION IN 
 * modules/system/region.tpl.php
 */
?>
<section class="twocols clearfix">
<?php if ($content): ?>
  <?php print $content; ?>
<?php endif; ?>
</section>