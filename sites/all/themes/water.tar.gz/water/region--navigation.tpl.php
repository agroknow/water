<?php
/*
 * REGION THEMING
 * https://www.drupal.org/node/1089656
 * 
 * DEFAULT region.tpl.php IMPLEMENTATION IN 
 * modules/system/region.tpl.php
 */
?>
<?php if ($content): ?>
  <nav class="main">
    <?php print $content; ?>
  </nav>
<?php endif; ?>