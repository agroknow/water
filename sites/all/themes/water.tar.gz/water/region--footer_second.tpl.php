<section class="footer-middle">
     <div class="center clearfix">
<?php if ($content): ?>
  <?php print $content; ?>
<?php endif; ?>
    </div>
</section>