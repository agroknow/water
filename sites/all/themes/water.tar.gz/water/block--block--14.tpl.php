<?php
/*
 * Twitter Slider
 */
?>
<section id="twitterslider" data-theme-tpl="block--block--14">            
    <div class="center">
        <div id="twitterslides">
            <div>
                <blockquote class="twitter-tweet" lang="en"><p>EU VAT Action is a campaign group representing the very tiny businesses caught up in <a href="https://twitter.com/hashtag/VATMOSS?src=hash">#VATMOSS</a> <a href="http://t.co/DfrWFz2xQ3">http://t.co/DfrWFz2xQ3</a></p>&mdash; Rachel Andrew (@rachelandrew) <a href="https://twitter.com/rachelandrew/status/542993377110003712">December 11, 2014</a></blockquote>
            </div>
            <div>
                <blockquote class="twitter-tweet" data-cards="hidden" lang="en"><p>Oh the dreaded open-office floor plan—here&#39;s how to deal. <a href="http://t.co/fVgmmc5Q8l">http://t.co/fVgmmc5Q8l</a></p>&mdash; Fast Company (@FastCompany) <a href="https://twitter.com/FastCompany/status/542992954106068992">December 11, 2014</a></blockquote>
            </div>
            <div>
                <blockquote class="twitter-tweet" data-cards="hidden" lang="en"><p>Killed for being Black while sleeping inside of his apartment on his coach <a href="http://t.co/VKCLe2rxb0">http://t.co/VKCLe2rxb0</a> <a href="https://twitter.com/hashtag/TravisFaison?src=hash">#TravisFaison</a> <a href="https://twitter.com/hashtag/BlackLivesMatter?src=hash">#BlackLivesMatter</a></p>&mdash; No Justice, No Peace (@AmyStephen) <a href="https://twitter.com/AmyStephen/status/542992023637475328">December 11, 2014</a></blockquote>
            </div>
        </div>
    </div>
</section>