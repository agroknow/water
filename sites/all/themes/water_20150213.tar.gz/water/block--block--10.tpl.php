<?php
/*
 * Connect with us
 */
?>
<nav class="socials">
<?php if ($block->subject): ?>
  <h3><?php print $block->subject ?></h3>
<?php endif;?>
    <div class="clearfix">
        <a href="#" class="facebook ir">facebook</a>
        <a href="#" class="twitter ir">twitter</a>
        <a href="#" class="googleplus ir">googleplus</a>
    </div>
    <div class="clearfix">
        <a href="#" class="instagram ir">instagram</a>
        <a href="#" class="linkedin ir">linkedin</a>
        <a href="#" class="youtube ir">youtube</a>
    </div>
</nav>