<?php 
print $content 
?>