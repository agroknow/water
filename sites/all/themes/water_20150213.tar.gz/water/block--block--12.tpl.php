<?php
/*
 * Copyright
 */
?>
<div>Copyright 2015</div>
<a href="http://www.redpanda.gr" title="Designed by RedPanda">Designed by <span>RedPanda</span></a>