<section class="search clearfix">
    <?php print $content ?>
    <a href="#">A-z Glossary</a>
    <a href="<?php print base_path(); ?>search/node">Advanced Search</a>
</section>
