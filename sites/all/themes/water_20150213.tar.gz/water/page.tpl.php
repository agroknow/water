<header id="header">
    <div class="center clearfix">
<!-- *****
logo
****** -->
        <?php if ($logo):?>
        <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home" class="logo ir"><?php print $site_name;?></a>
        <?php endif; ?>
<!-- *****
blocks: user_menu / lang_switcher
****** -->
        <?php print render($page['header_top_right']); ?>
<!-- *****
blocks: main_menu
****** -->
        <?php print render($page['navigation']); ?>
<!-- *****
blocks: search
****** -->
        <?php print render($page['header']); ?>
    </div>
</header>

<section>
    <!-- #messages -->
    <?php if ($messages):?>
    <div id="messages-console" class="clearfix"><?php print $messages; ?></div>
    <?php endif; ?>

    <!-- #breadcrumb -->
    <?php print $breadcrumb; ?>

    <!-- #title -->
    <?php print render($title_prefix); ?>
    <?php if ($title):?>
    <h1><?php print $title; ?></h1>
    <?php endif; ?>
    <?php print render($title_suffix); ?>

    <!-- #help -->
    <?php print render($page['help']); ?>

    <!-- #tabs -->
    <?php if ($tabs):?>
    <div class="tabs"><?php print render($tabs); ?></div>
    <?php endif; ?>

    <!-- #action_links -->
    <?php if ($action_links):?>
    <ul class="action-links"><?php print render($action_links); ?></ul>
    <?php endif; ?>

    <!-- #content -->
    <?php print render($page['content']); ?>

    <!-- #feed_icons -->
    <?php print $feed_icons; ?>
</section>

<footer id="footer">
<!-- *****
blocks: bottom_menu, connect_with_us, contact_us
****** -->
    <?php print render($page['footer_first']); ?>    
<!-- *****
blocks: partners
****** -->
    <?php print render($page['footer_second']); ?>
<!-- *****
blocks: copyright
****** -->
    <?php print render($page['footer_third']); ?>
</footer>