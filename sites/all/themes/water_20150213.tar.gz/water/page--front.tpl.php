<header id="header">
    <div class="center clearfix">
<!-- *****
logo
****** -->
        <?php if ($logo):?>
        <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home" class="logo ir"><?php print $site_name;?></a>
        <?php endif; ?>
<!-- *****
blocks: user_menu / lang_switcher
****** -->
        <?php print render($page['header_top_right']); ?>
<!-- *****
blocks: main_menu
****** -->
        <?php print render($page['navigation']); ?>
<!-- *****
blocks: search
****** -->
        <?php print render($page['header']); ?>
    </div>
</header>

<section id="slider">
<!-- slider http://kenwheeler.github.io/slick/ -->
    <div id="slides">
        <div class="slide" style="background:#f26c4f url(<?php print base_path() . path_to_theme(); ?>/img/ss1_mini.jpg) top center no-repeat;"></div>
        <div class="slide" style="background:#f26c4f url(<?php print base_path() . path_to_theme(); ?>/img/ss2_mini.jpg) top center no-repeat;"></div>
        <div class="slide" style="background:#f26c4f url(<?php print base_path() . path_to_theme(); ?>/img/ss3_mini.jpg) top center no-repeat;"></div>
    </div>
<!-- about_us -->
    <aside>
        <div class="center clearfix">
            <h2><?php print t('About Us')?></h2>
            <p><?php print t('Our knowledge hub is a developing platform to support global exposure assessments, risk assessments, and enable evaluation of sanitation technologies for achieving health-based targets. The current GWP network of scientists and students are developing an open access online resource for sharing and retrieving databases, quantitative information, tools and educational materials on pathogens associated with excreta and wastewater.')?></p>
        </div>
    </aside>
</section>

<section id="blocks">            
<!-- *****
blocks: featured_sections, science_links, view_events, view_latest_news
****** -->
    <div class="center">
<!-- featured_sections -->
        <h2 class="centered">Featured Sections</h2>
        <div class="clearfix">
            <a href="#" class="topicons">
                <span class="icon library ir">Library</span>
                <h3>Library</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent luctus, erat at.</p>
            </a>
            <a href="#" class="topicons">
                <span class="icon publications ir">Publications</span>
                <h3>Publications</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent luctus, erat at.</p>
            </a>
            <a href="#" class="topicons">
                <span class="icon presentations ir">Presentations</span>
                <h3>Presentations</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent luctus, erat at.</p>
            </a>
            <a href="#" class="topicons">
                <span class="icon seminars ir">Seminars</span>
                <h3>Seminars</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent luctus, erat at.</p>
            </a>
        </div>
<!-- science_links -->
        <h2 class="centered">Science Links</h2>
        <div class="clearfix">
            <a href="#" class="exticons quantitative clearfix">
                <span>Quantitative Microbial Risk Assessment</span>
            </a>
            <a href="#" class="exticons global clearfix">
                <span>Global Atlas of Helminth Infections</span>
            </a>
        </div>                
        <section class="twocols clearfix">                    
            <section class="slidelist">
<!-- view_events -->
                <h2 class="withrightlink clearfix">Events<a href="#">All events</a></h2>
                <article class="event clearfix">
                    <time datetime="2014-12-20 20:00"><span>20</span> January</time>
                    <h3><a href="#">This is a test event title</a></h3>
                    <a href="#" class="slidetoggle ir">open/close</a>
                    <section class="clearfix toslide">
                        <img src="img/sample100x75.jpg" />
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus risus libero, suscipit vestibulum risus a. </p>
                        <a href="#" class="more">more</a>
                    </section>
                </article>                        
                <article class="event clearfix">
                    <time datetime="2014-12-20 20:00"><span>20</span> January</time>
                    <h3><a href="#">This is a test event title</a></h3>
                    <a href="#" class="slidetoggle ir">open/close</a>
                    <section class="clearfix toslide">
                        <img src="img/sample100x75.jpg" />
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus risus libero, suscipit vestibulum risus a. </p>
                        <a href="#" class="more">more</a>
                    </section>
                </article>                        
                <article class="event clearfix">
                    <time datetime="2014-12-20 20:00"><span>20</span> January</time>
                    <h3><a href="#">This is a test event title</a></h3>
                    <a href="#" class="slidetoggle ir">open/close</a>
                    <section class="clearfix toslide">
                        <img src="img/sample100x75.jpg" />
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus risus libero, suscipit vestibulum risus a. </p>
                        <a href="#" class="more">more</a>
                    </section>
                </article>                        
                <article class="event clearfix">
                    <time datetime="2014-12-20 20:00"><span>20</span> January</time>
                    <h3><a href="#">This is a test event title</a></h3>
                    <a href="#" class="slidetoggle ir">open/close</a>
                    <section class="clearfix toslide">
                        <img src="img/sample100x75.jpg" />
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus risus libero, suscipit vestibulum risus a. </p>
                        <a href="#" class="more">more</a>
                    </section>
                </article>                        
            </section>                    
            <section class="simpleview">
<!-- view_latest_news -->
                <h2 class="withrightlink clearfix">Latest News<a href="#">All news</a></h2>
                <article class="clearfix">
                    <time datetime="2014-12-20 20:00"><span>20</span> January</time>
                    <img src="img/sample170x92.jpg" />
                    <h3>This is a latest new title</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus risus libero. </p>
                    <footer class="clearfix"><a href="#" class="author">by GKB</a><a href="#" class="more">more</a></footer>
                </article>                        
                <article class="clearfix">
                    <time datetime="2014-12-20 20:00"><span>20</span> January</time>
                    <img src="img/sample170x92.jpg" />
                    <h3>This is a latest new title</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus risus libero. </p>
                    <footer class="clearfix"><a href="#" class="author">by GKB</a><a href="#" class="more">more</a></footer>
                </article>                        
                <article class="clearfix">
                    <time datetime="2014-12-20 20:00"><span>20</span> January</time>
                    <img src="img/sample170x92.jpg" />
                    <h3>This is a latest new title</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus risus libero. </p>
                    <footer class="clearfix"><a href="#" class="author">by GKB</a><a href="#" class="more">more</a></footer>
                </article>                        
            </section>                    
        </section>            
    </div>            
</section><!-- #blocks-->

<!-- *****
blocks: twitter_slider
****** -->
<section id="twitterslider">            
    <div class="center">
        <div id="twitterslides">
            <div>
                <blockquote class="twitter-tweet" lang="en"><p>EU VAT Action is a campaign group representing the very tiny businesses caught up in <a href="https://twitter.com/hashtag/VATMOSS?src=hash">#VATMOSS</a> <a href="http://t.co/DfrWFz2xQ3">http://t.co/DfrWFz2xQ3</a></p>&mdash; Rachel Andrew (@rachelandrew) <a href="https://twitter.com/rachelandrew/status/542993377110003712">December 11, 2014</a></blockquote>
            </div>
            <div>
                <blockquote class="twitter-tweet" data-cards="hidden" lang="en"><p>Oh the dreaded open-office floor plan—here&#39;s how to deal. <a href="http://t.co/fVgmmc5Q8l">http://t.co/fVgmmc5Q8l</a></p>&mdash; Fast Company (@FastCompany) <a href="https://twitter.com/FastCompany/status/542992954106068992">December 11, 2014</a></blockquote>
            </div>
            <div>
                <blockquote class="twitter-tweet" data-cards="hidden" lang="en"><p>Killed for being Black while sleeping inside of his apartment on his coach <a href="http://t.co/VKCLe2rxb0">http://t.co/VKCLe2rxb0</a> <a href="https://twitter.com/hashtag/TravisFaison?src=hash">#TravisFaison</a> <a href="https://twitter.com/hashtag/BlackLivesMatter?src=hash">#BlackLivesMatter</a></p>&mdash; No Justice, No Peace (@AmyStephen) <a href="https://twitter.com/AmyStephen/status/542992023637475328">December 11, 2014</a></blockquote>
            </div>
        </div>
    </div>
</section>

<footer id="footer">
<!-- *****
blocks: bottom_menu, connect_with_us, contact_us
****** -->
    <?php print render($page['footer_first']); ?>
<!-- *****
blocks: partners
****** -->
    <?php print render($page['footer_second']); ?>
<!-- *****
blocks: copyright
****** -->
    <?php print render($page['footer_third']); ?>
</footer>